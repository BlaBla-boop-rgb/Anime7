package dev.animecosmetics.mixin;

import dev.animecosmetics.title.TotemFx;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.client.sounds.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Mutes the vanilla totem sound while your totem pops with "Death Can't Die" switched on. */
@Mixin({SoundManager.class})
public abstract class SoundManagerMixin {
   @Inject(
      method = {"play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void animecosmetics$muteTotem(SoundInstance sound, CallbackInfoReturnable<SoundEngine.PlayResult> cir) {
      if (TotemFx.muted()) {
         SoundEngine.PlayResult[] results = SoundEngine.PlayResult.values();
         // the last value is "not started"
         cir.setReturnValue(results[results.length - 1]);
      }
   }
}
