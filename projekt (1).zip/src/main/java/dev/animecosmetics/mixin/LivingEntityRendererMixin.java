package dev.animecosmetics.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.animecosmetics.fx.AshDeath;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.UvMapping;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Kill animation (ported from Ronova): darkens, cracks and collapses mobs that turn to ash. */
@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> {
   @Shadow
   protected M model;

   @Shadow
   public abstract Identifier getTextureLocation(S var1);

   @Inject(
      method = {"extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void animecosmetics$ashExtract(T entity, S state, float partialTicks, CallbackInfo ci) {
      AshDeath.extract(entity, state);
   }

   @Inject(
      method = {"submit"},
      at = {@At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",
         ordinal = 0,
         shift = Shift.AFTER
      )}
   )
   private void animecosmetics$ashCollapse(S state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
      AshDeath.collapse(state, poseStack);
   }

   @ModifyArg(
      method = {"submit"},
      at = {@At(
         value = "INVOKE",
         target = "submitModel",
         ordinal = 0
      )},
      index = 6
   )
   private int animecosmetics$ashTint(Model<?> m, Object state, PoseStack ps, RenderType rt, int light, int overlay, int color, UvMapping uv, int outline) {
      return state instanceof LivingEntityRenderState ls ? AshDeath.tint(ls, color) : color;
   }

   @Inject(
      method = {"submit"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/entity/layers/RenderLayer;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/EntityRenderState;FF)V"
      )}
   )
   private void animecosmetics$ashLayersOn(S state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
      AshDeath.layerTint = AshDeath.tint(state, -1);
   }

   @Inject(
      method = {"submit"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/entity/layers/RenderLayer;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/EntityRenderState;FF)V",
         shift = Shift.AFTER
      )}
   )
   private void animecosmetics$ashLayersOff(S state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
      AshDeath.layerTint = -1;
   }

   @Inject(
      method = {"submit"},
      at = {@At(
         value = "INVOKE",
         target = "submitModel",
         ordinal = 0,
         shift = Shift.AFTER
      )}
   )
   private void animecosmetics$ashCracks(S state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
      int ch = AshDeath.charColor(state);
      if (ch >>> 24 > 2) {
         collector.order(1)
            .submitModel(
               this.model, state, poseStack, AshDeath.charType(this.getTextureLocation(state)), state.lightCoords, OverlayTexture.NO_OVERLAY, ch, null, 0
            );
      }

      int c = AshDeath.crackColor(state);
      if (c >>> 24 > 2) {
         collector.order(2)
            .submitModel(
               this.model, state, poseStack, AshDeath.crackType(state, this.getTextureLocation(state)), 15728880, OverlayTexture.NO_OVERLAY, c, null, 0
            );
      }
   }
}
