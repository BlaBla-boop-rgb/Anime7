package dev.animecosmetics.title;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.animecosmetics.AnimeCosmetics;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import org.joml.Vector3f;

/** The parts of Ronova's FeatherFx that the title feathers need: feather atlas layout and feather shape. */
final class FeatherFx {
   private static int variants = -1;
   private static int cellW = 128;
   private static int cellH = 256;
   private static int[][] boxes = new int[][]{{47, 6, 80, 250}};
   private static final Vector3f SA = new Vector3f();
   private static final Vector3f SC = new Vector3f();
   private static final Vector3f SN = new Vector3f();
   private static final Vector3f S0 = new Vector3f();
   private static final Vector3f S1 = new Vector3f();
   private static final Vector3f S2 = new Vector3f();

   private FeatherFx() {
   }

   static int variants() {
      if (variants < 0) {
         variants = 1;
         Minecraft.getInstance().getResourceManager().getResource(AnimeCosmetics.id("meshes/feather.json")).ifPresent(res -> {
            try (Reader r = new InputStreamReader(res.open(), StandardCharsets.UTF_8)) {
               JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
               variants = Math.max(1, o.get("count").getAsInt());
               cellW = o.getAsJsonArray("cell").get(0).getAsInt();
               cellH = o.getAsJsonArray("cell").get(1).getAsInt();
               JsonArray arr = o.getAsJsonArray("box");
               boxes = new int[arr.size()][4];

               for (int i = 0; i < boxes.length; i++) {
                  for (int k = 0; k < 4; k++) {
                     boxes[i][k] = arr.get(i).getAsJsonArray().get(k).getAsInt();
                  }
               }
            } catch (Exception var8) {
               AnimeCosmetics.LOGGER.warn("feather.json: {}", var8.toString());
            }
         });
      }

      return variants;
   }

   static int[] atlasSize() {
      variants();
      return new int[]{cellW * boxes.length, cellH * 4};
   }

   static FeatherFx.Frame frame(FeatherSim.Body fb, int layer) {
      variants();
      int var = Math.min(fb.variant, boxes.length - 1);
      int[] bx = boxes[var];
      float bw = bx[2] - bx[0];
      float bh = bx[3] - bx[1];
      float m = layer == 1 ? 14.0F : 0.0F;
      float pu0 = Math.max(0.0F, bx[0] - m);
      float pu1 = Math.min((float)cellW, bx[2] + m);
      float pv0 = Math.max(0.0F, bx[1] - m);
      float pv1 = Math.min((float)cellH, bx[3] + m);
      float L = fb.length * (pv1 - pv0) / bh;
      float W = fb.length * (bw / bh) * (pu1 - pu0) / bw;
      float phiMax = 1.25F * fb.curl * W / (fb.length * bw / bh);
      float atlasW = cellW * boxes.length;
      float atlasH = cellH * 4;
      float row = layer * cellH;
      return new FeatherFx.Frame((var * cellW + pu0) / atlasW, (var * cellW + pu1) / atlasW, (row + pv0) / atlasH, (row + pv1) / atlasH, L, W, phiMax);
   }

   static void shape(FeatherSim.Body fb, float time, FeatherFx.Frame fr, int nl, int nw, Vector3f[][] out) {
      fb.axis(0, SA);
      fb.axis(1, SC);
      fb.axis(2, SN);
      float L = fr.length();
      float W = fr.width();
      float phiMax = fr.phiMax();
      float bend = (0.25F + 0.9F * fb.curl) * fb.bendSign;
      float wave = 0.18F * Math.min(1.0F, fb.v.length() / 1.2F);
      float ds = L / nl;
      float ax = 0.0F;
      float nz = 0.0F;
      float[] ca = new float[nl + 1];
      float[] cn = new float[nl + 1];
      float[] be = new float[nl + 1];

      for (int i = 0; i <= nl; i++) {
         float t = (float)i / nl;
         float beta = bend * t * t + wave * (float)Math.sin(6.0F * t - 9.0F * time + fb.seed) * t;
         be[i] = beta;
         ca[i] = ax;
         cn[i] = nz;
         ax += ds * (float)Math.cos(beta);
         nz += ds * (float)Math.sin(beta);
      }

      float mx = ax / 2.0F;
      float mz = nz / 2.0F;

      for (int i = 0; i <= nl; i++) {
         float cosB = (float)Math.cos(be[i]);
         float sinB = (float)Math.sin(be[i]);

         for (int j = 0; j <= nw; j++) {
            float u = (float)j / nw * 2.0F - 1.0F;
            float lc;
            float ln;
            if (phiMax > 0.001F) {
               float k = phiMax / (W / 2.0F);
               float ph = u * phiMax;
               lc = (float)Math.sin(ph) / k;
               ln = (1.0F - (float)Math.cos(ph)) / k * fb.bendSign;
            } else {
               lc = u * W / 2.0F;
               ln = 0.0F;
            }

            float pa = ca[i] - mx - ln * sinB;
            float pn = cn[i] - mz + ln * cosB;
            out[i][j].set(fb.p).add(S0.set(SA).mul(pa)).add(S1.set(SC).mul(lc)).add(S2.set(SN).mul(pn));
         }
      }
   }

   record Frame(float u0, float u1, float vTop, float vBot, float length, float width, float phiMax) {
   }
}
