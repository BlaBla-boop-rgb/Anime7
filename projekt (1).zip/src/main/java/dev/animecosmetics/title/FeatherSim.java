package dev.animecosmetics.title;

import java.util.Random;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class FeatherSim {
   static final float G = 9.8F;
   static final float DT = 0.004166667F;
   private static final float KN = 100.0F;
   private static final float KT = 0.9F;
   private static final float K_AIR = 0.12F;
   private static final float W_MAX = 40.0F;
   private static final Vector3f A = new Vector3f();
   private static final Vector3f C = new Vector3f();
   private static final Vector3f N = new Vector3f();
   private static final Vector3f VR = new Vector3f();
   private static final Vector3f VT = new Vector3f();
   private static final Vector3f FN = new Vector3f();
   private static final Vector3f F = new Vector3f();
   private static final Vector3f R = new Vector3f();
   private static final Vector3f TAU = new Vector3f();
   private static final Vector3f TB = new Vector3f();
   private static final Vector3f IW = new Vector3f();
   private static final Vector3f TMP = new Vector3f();
   private static final Quaternionf QI = new Quaternionf();
   private static final Quaternionf DQ = new Quaternionf();

   private FeatherSim() {
   }

   public static FeatherSim.Body spawn(Random r, int variants, float x, float y, float z, float vx, float vy, float vz) {
      FeatherSim.Body b = new FeatherSim.Body(r, variants);
      b.p.set(x, y, z);
      b.v.set(vx, vy, vz);
      Matrix3f base = new Matrix3f(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F);
      Quaternionf qb = base.getNormalizedRotation(new Quaternionf());
      b.q.rotationY(r.nextFloat() * (float) Math.PI * 2.0F).mul(qb).rotateX((r.nextFloat() * 2.0F - 1.0F) * 0.6F);
      b.w.set((r.nextFloat() * 2.0F - 1.0F) * 0.6F, (r.nextFloat() * 2.0F - 1.0F) * 0.4F, (r.nextFloat() * 2.0F - 1.0F) * 0.4F);
      return b;
   }

   public static void gust(FeatherSim.Body b, float dx, float dy, float dz, float u0, float tau, float tumbleD0, float tumbleDur) {
      b.gustDir.set(dx, dy, dz).normalize();
      b.gustU0 = u0;
      b.gustTau = tau;
      b.tumbleD0 = tumbleD0;
      b.tumbleDur = tumbleDur;
   }

   public static void step(FeatherSim.Body b, Vector3f wind) {
      b.axis(0, A);
      b.axis(1, C);
      b.axis(2, N);
      VR.set(b.v).sub(wind);
      if (b.gustU0 > 0.0F) {
         float g = b.gustU0 * (float)Math.exp(-b.age / b.gustTau);
         VR.sub(b.gustDir.x * g, b.gustDir.y * g, b.gustDir.z * g);
      }

      float vn = VR.dot(N);
      VT.set(N).mul(-vn).add(VR);
      float target = clamp(b.curl0 + 0.12F * vn, 0.05F, 0.95F);
      b.curlV = b.curlV + (-196.0F * (b.curl - target) - 9.8F * b.curlV) * 0.004166667F;
      b.curl = clamp(b.curl + b.curlV * 0.004166667F, 0.0F, 1.0F);
      float area = 1.0F - 0.3F * b.curl;
      float speed = VR.length();
      float kk = 100.0F * area * speed * 0.004166667F;
      FN.set(N).mul((vn / (1.0F + kk) - vn) / 0.004166667F);
      F.set(VT).mul(-0.9F).add(FN).add(0.0F, -9.8F, 0.0F);
      TAU.zero();
      float sp = VT.length();
      if (sp > 1.0E-6F) {
         float dc = VT.dot(C) / sp;
         float da = VT.dot(A) / sp;
         float k = b.cp * Math.min(1.0F, sp / 0.3F);
         R.set(C).mul(b.width * dc * k).add(TMP.set(A).mul(0.9F * b.length * da * k));
         R.cross(FN, TAU);
      }

      TAU.add(TMP.set(N).mul(b.spin * 0.004F * b.curl * vn));
      b.q.conjugate(QI).transform(TAU, TB);
      Vector3f wb = b.w;
      IW.set(b.ia * wb.x, b.ic * wb.y, b.in * wb.z);
      wb.cross(IW, TMP);
      TB.sub(TMP);
      wb.add(TB.x / b.ia * 0.004166667F, TB.y / b.ic * 0.004166667F, TB.z / b.in * 0.004166667F);
      float k2 = Math.min(1.0F, b.age / b.tumbleDur);
      float dm = b.tumbleD0 + (1.0F - b.tumbleD0) * k2 * k2;
      wb.mul((float)Math.exp(-dm * (b.damp * 3.0F + 0.35F * wb.length()) * 0.004166667F));
      if (wb.length() > 40.0F) {
         wb.mul(40.0F / wb.length());
      }

      b.v.add(F.x * 0.004166667F, F.y * 0.004166667F, F.z * 0.004166667F);
      b.p.add(b.v.x * 0.004166667F, b.v.y * 0.004166667F, b.v.z * 0.004166667F);
      b.age += 0.004166667F;
      float ang = wb.length() * 0.004166667F;
      if (ang > 1.0E-9F) {
         DQ.fromAxisAngleRad(wb.x / wb.length(), wb.y / wb.length(), wb.z / wb.length(), ang);
         b.q.mul(DQ).normalize();
      }
   }

   static float clamp(float x, float lo, float hi) {
      return x < lo ? lo : Math.min(hi, x);
   }

   public static final class Body {
      public final Vector3f p = new Vector3f();
      public final Vector3f v = new Vector3f();
      public final Quaternionf q = new Quaternionf();
      final Vector3f w = new Vector3f();
      public float curl;
      public float curlV;
      public final float length;
      public final float width;
      public final float curl0;
      public final float cp;
      public final float damp;
      public final float spin;
      final float ia;
      final float ic;
      final float in;
      public final int variant;
      public final float seed;
      public final float bendSign;
      public float age;
      public final Vector3f gustDir = new Vector3f();
      public float gustU0;
      public float gustTau = 0.7F;
      public float tumbleD0 = 1.0F;
      public float tumbleDur = 1.8F;

      Body(Random r, int variants) {
         this.length = 0.24F + r.nextFloat() * 0.12F;
         this.width = this.length * 0.3F;
         this.curl0 = 0.1F + r.nextFloat() * 0.75F;
         this.cp = 0.18F + r.nextFloat() * 0.12F;
         this.damp = 5.0F + r.nextFloat() * 3.0F;
         this.spin = (r.nextBoolean() ? 1 : -1) * (0.5F + r.nextFloat());
         this.curl = this.curl0;
         this.variant = variants <= 1 ? 0 : r.nextInt(variants);
         this.seed = r.nextFloat() * 100.0F;
         this.bendSign = r.nextBoolean() ? 1.0F : -1.0F;
         float l2 = this.length * this.length;
         float w2 = this.width * this.width;
         this.ia = w2 / 12.0F * 9.0F;
         this.ic = l2 / 12.0F * 2.0F;
         this.in = (l2 + w2) / 12.0F * 1.5F;
      }

      public void kick(Random r, float s) {
         this.w.set((r.nextFloat() * 2.0F - 1.0F) * s, (r.nextFloat() * 2.0F - 1.0F) * s, (r.nextFloat() * 2.0F - 1.0F) * s * 0.3F);
      }

      public Vector3f axis(int i, Vector3f out) {
         return this.q.transform(out.set(i == 0 ? 1.0F : 0.0F, i == 1 ? 1.0F : 0.0F, i == 2 ? 1.0F : 0.0F));
      }
   }
}
