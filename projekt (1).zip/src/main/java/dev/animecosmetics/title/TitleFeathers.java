package dev.animecosmetics.title;

import dev.animecosmetics.AnimeCosmetics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2f;
import org.joml.Vector3f;

final class TitleFeathers {
   private static final Identifier TEX = AnimeCosmetics.id("textures/entity/fx/feather.png");
   private static final int NL = 8;
   private static final int COUNT = 28;
   private static final List<TitleFeathers.F> LIST = new ArrayList<>();
   private static float simT;
   private static float acc;
   private static final Vector3f WIND = new Vector3f();
   private static final Vector3f[][] P = new Vector3f[9][3];
   private static final Matrix3x2f M;

   private TitleFeathers() {
   }

   static void play(float from) {
      LIST.clear();
      simT = 0.0F;
      acc = 0.0F;
      Random r = new Random();
      int variants = FeatherFx.variants();

      for (int i = 0; i < 28; i++) {
         TitleFeathers.F f = new TitleFeathers.F();
         f.x0 = 560.0F + r.nextFloat() * 800.0F;
         f.y0 = 330.0F + r.nextFloat() * 370.0F;
         f.scale = 290.0F + r.nextFloat() * 230.0F;
         float dx = (f.x0 - 960.0F) / 400.0F;
         float dy = -(f.y0 - 540.0F) / 400.0F + 0.35F + r.nextFloat() * 0.4F;
         float dz = (r.nextFloat() * 2.0F - 1.0F) * 0.4F;
         float u0 = 2.6F * (0.7F + 0.6F * r.nextFloat());
         float len = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
         f.b = FeatherSim.spawn(r, variants, 0.0F, 0.0F, 0.0F, dx / len * u0 * 0.5F, dy / len * u0 * 0.5F, dz / len * u0 * 0.5F);
         FeatherSim.gust(f.b, dx, dy, dz, u0, 0.7F, 0.1F, 1.8F);
         f.b.kick(r, 6.0F);
         f.t0 = from + r.nextFloat() * r.nextFloat() * 1.2F;
         LIST.add(f);
      }
   }

   static void render(GuiGraphicsExtractor g, float t, float fade) {
      float dt = Math.max(0.0F, Math.min(0.1F, t - simT));
      simT = t;
      acc += dt;

      while (acc >= 0.004166667F) {
         acc -= 0.004166667F;

         for (TitleFeathers.F f : LIST) {
            if (t >= f.t0) {
               float s = f.b.seed;
               WIND.set(0.14F * (float)Math.sin(t * 0.8 + s), 0.0F, 0.1F * (float)Math.cos(t * 0.6 + s * 1.7));
               FeatherSim.step(f.b, WIND);
            }
         }
      }

      for (TitleFeathers.F fx : LIST) {
         float age = t - fx.t0;
         if (!(age <= 0.0F)) {
            float a = smooth(age / 0.25F) * fade;
            if (!(a <= 0.01F)) {
               float rim = 0.35F + 0.15F * (float)Math.sin(age * 3.1 + fx.b.seed);
               draw(g, fx, t, 1, 14684184, a * 0.55F);
               draw(g, fx, t, 0, 16777215, a);
               draw(g, fx, t, 2, 16722458, a * rim);
            }
         }
      }
   }

   private static void draw(GuiGraphicsExtractor g, TitleFeathers.F f, float time, int layer, int rgb, float alpha) {
      FeatherFx.Frame fr = FeatherFx.frame(f.b, layer);
      FeatherFx.shape(f.b, time, fr, 8, 2, P);
      int[] atlas = FeatherFx.atlasSize();
      int aw = atlas[0];
      int ah = atlas[1];
      int pu0 = Math.round(fr.u0() * aw);
      int pu1 = Math.round(fr.u1() * aw);
      int pvTop = Math.round(fr.vTop() * ah);
      int pvBot = Math.round(fr.vBot() * ah);
      int col = ARGB.color(Mth.clamp((int)(alpha * 255.0F), 0, 255), rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);

      for (int i = 0; i < 8; i++) {
         int vA = pvBot + Math.round((float)(pvTop - pvBot) * (i + 1) / 8.0F);
         int vB = pvBot + Math.round((float)(pvTop - pvBot) * i / 8.0F);
         int sh = vB - vA;
         if (sh > 0) {
            float lx1 = sx(f, P[i + 1][0]);
            float ly1 = sy(f, P[i + 1][0]);
            float rx1 = sx(f, P[i + 1][2]);
            float ry1 = sy(f, P[i + 1][2]);
            float lx0 = sx(f, P[i][0]);
            float ly0 = sy(f, P[i][0]);
            float rx0 = sx(f, P[i][2]);
            float ry0 = sy(f, P[i][2]);
            float xX = (rx1 - lx1 + (rx0 - lx0)) / 2.0F;
            float xY = (ry1 - ly1 + (ry0 - ly0)) / 2.0F;
            float yX = (lx0 - lx1 + (rx0 - rx1)) / 2.0F * 1.06F;
            float yY = (ly0 - ly1 + (ry0 - ry1)) / 2.0F * 1.06F;
            float cx = (lx0 + lx1 + rx0 + rx1) / 4.0F;
            float cy = (ly0 + ly1 + ry0 + ry1) / 4.0F;
            float ox = cx - (xX + yX) / 2.0F;
            float oy = cy - (xY + yY) / 2.0F;
            int q = 64;
            M.set(xX / q, xY / q, yX / q, yY / q, ox, oy);
            g.pose().pushMatrix();
            g.pose().mul(M);
            g.blit(RenderPipelines.GUI_TEXTURED, TEX, 0, 0, pu0, vA, q, q, pu1 - pu0, sh, aw, ah, col);
            g.pose().popMatrix();
         }
      }
   }

   private static float sx(TitleFeathers.F f, Vector3f p) {
      return f.x0 + p.x * f.scale;
   }

   private static float sy(TitleFeathers.F f, Vector3f p) {
      return f.y0 - p.y * f.scale;
   }

   private static float smooth(float x) {
      x = Mth.clamp(x, 0.0F, 1.0F);
      return x * x * (3.0F - 2.0F * x);
   }

   static {
      for (Vector3f[] row : P) {
         for (int j = 0; j < 3; j++) {
            row[j] = new Vector3f();
         }
      }

      M = new Matrix3x2f();
   }

   private static final class F {
      FeatherSim.Body b;
      float t0;
      float scale;
      float x0;
      float y0;
   }
}
