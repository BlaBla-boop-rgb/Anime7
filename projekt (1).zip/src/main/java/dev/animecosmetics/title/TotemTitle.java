package dev.animecosmetics.title;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.animecosmetics.AnimeCosmetics;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import net.minecraft.client.DeltaTracker;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;

/**
 * The "Ruler of Death" title animation from Ronova, played when your totem pops, with the text
 * "Death Can't Die" (textures/gui/title/title.png, title_glow.png and title_sheen.png were made for it).
 */
public final class TotemTitle {
   private static final SoundEvent SOUND = SoundEvent.createFixedRangeEvent(AnimeCosmetics.id("title"), 16.0F);
   private static final String DIR = "textures/gui/title/";
   private static final float FALL = 0.35F;
   private static final float PEAK = 1.25F;
   private static final float HOLD = 3.3F;
   private static final float END = 4.1F;
   private static final float CX = 960.0F;
   private static final float CY = 540.0F;
   private static final List<float[]> SPARKS = new ArrayList<>();
   private static final List<float[]> AREA = new ArrayList<>();
   private static final List<float[]> FLAMES = new ArrayList<>();
   private static final List<float[]> DOTS = new ArrayList<>();
   private static final List<float[]> SHARDS = new ArrayList<>();
   private static final List<float[]> GLINTS = new ArrayList<>();
   private static final List<float[]> RAYS = new ArrayList<>();
   private static final List<float[]> DUST = new ArrayList<>();
   private static Map<String, TotemTitle.Layer> layers;
   private static final List<TotemTitle.Layer> EYES = new ArrayList<>();
   private static final List<String> EYE_NAMES = new ArrayList<>();
   private static final Map<String, float[]> GAZE = new HashMap<>();
   private static final float GAZE_SLOT = 0.12F;
   private static final float GAZE_JUMP = 0.3F;
   private static final float SACCADE = 0.06F;
   private static final float GAZE_AMP = 0.55F;
   private static long t0 = -1L;
   private static int gazeSeed;
   private static final int FIRE_N = 24;
   private static final int FIRE_COLS = 6;

   private TotemTitle() {
   }

   public static void register() {
      HudElementRegistry.addLast(AnimeCosmetics.id("totem_title"), TotemTitle::render);
   }

   public static boolean playing() {
      return t0 >= 0L;
   }

   public static void clear() {
      t0 = -1L;
   }

   public static void play() {
      t0 = System.nanoTime();
      Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SOUND, 1.0F, 1.0F));
      gazeSeed = (int)t0;
      TitleFeathers.play(0.35F);
      SPARKS.clear();
      Random r = new Random();

      for (float t = 0.75F; t < 3.2F; t += 0.03F * (float)Math.exp((t - 0.75F) / 0.95F) * (0.6F + 0.8F * r.nextFloat())) {
         float side = r.nextBoolean() ? 1.0F : -1.0F;
         SPARKS.add(
            new float[]{
               side * (690.0F + r.nextFloat() * 160.0F), -85.0F + r.nextFloat() * 170.0F, t, 45.0F + r.nextFloat() * 75.0F, r.nextFloat() < 0.4F ? 1.0F : 0.0F
            }
         );
      }

      AREA.clear();

      for (float var3 = 0.5F + r.nextFloat() * 0.15F; var3 < 3.4F; var3 += 0.07F + r.nextFloat() * 0.16F) {
         AREA.add(
            new float[]{
               -820.0F + r.nextFloat() * 1640.0F, -230.0F + r.nextFloat() * 460.0F, var3, 28.0F + r.nextFloat() * 50.0F, r.nextFloat() < 0.3F ? 1.0F : 0.0F
            }
         );
      }
   }

   private static void load() {
      layers = new HashMap<>();
      EYES.clear();
      EYE_NAMES.clear();
      GAZE.clear();
      Minecraft mc = Minecraft.getInstance();
      FLAMES.clear();
      DOTS.clear();
      SHARDS.clear();
      GLINTS.clear();
      RAYS.clear();
      DUST.clear();
      mc.getResourceManager().getResource(AnimeCosmetics.id("textures/gui/title/title_edge.json")).ifPresent(er -> {
         try (Reader r = new InputStreamReader(er.open(), StandardCharsets.UTF_8)) {
            JsonObject ox = JsonParser.parseReader(r).getAsJsonObject();
            readRows(ox, "flames", FLAMES);
            readRows(ox, "dots", DOTS);
            readRows(ox, "shards", SHARDS);
            readRows(ox, "glints", GLINTS);
            readRows(ox, "rays", RAYS);
            readRows(ox, "dust", DUST);
         } catch (Exception var6x) {
            AnimeCosmetics.LOGGER.warn("title_edge.json: {}", var6x.toString());
         }
      });
      Optional<Resource> res = mc.getResourceManager().getResource(AnimeCosmetics.id("textures/gui/title/title_layers.json"));
      if (res.isEmpty()) {
         AnimeCosmetics.LOGGER.warn("title_layers.json missing");
      } else {
         try (Reader r = new InputStreamReader(res.get().open(), StandardCharsets.UTF_8)) {
            JsonObject ls = JsonParser.parseReader(r).getAsJsonObject().getAsJsonObject("layers");

            for (String name : ls.keySet()) {
               JsonObject o = ls.getAsJsonObject(name);
               TotemTitle.Layer l = new TotemTitle.Layer(
                  AnimeCosmetics.id("textures/gui/title/" + name + ".png"),
                  o.get("x").getAsFloat(),
                  o.get("y").getAsFloat(),
                  o.get("w").getAsFloat(),
                  o.get("h").getAsFloat(),
                  o.getAsJsonArray("px").get(0).getAsInt(),
                  o.getAsJsonArray("px").get(1).getAsInt()
               );
               layers.put(name, l);
               if (name.startsWith("eye")) {
                  EYES.add(l);
                  EYE_NAMES.add(name);
               }

               if (o.has("gaze")) {
                  GAZE.put(name, new float[]{o.getAsJsonArray("gaze").get(0).getAsFloat(), o.getAsJsonArray("gaze").get(1).getAsFloat()});
               }
            }
         } catch (Exception var10) {
            AnimeCosmetics.LOGGER.warn("title_layers.json: {}", var10.toString());
         }
      }
   }

   private static void readRows(JsonObject o, String key, List<float[]> out) {
      for (JsonElement row : o.getAsJsonArray(key)) {
         JsonArray arr = row.getAsJsonArray();
         float[] f = new float[arr.size()];

         for (int i = 0; i < f.length; i++) {
            f[i] = arr.get(i).getAsFloat();
         }

         out.add(f);
      }
   }

   public static void render(GuiGraphicsExtractor g, DeltaTracker delta) {
      if (t0 >= 0L) {
         float t = (float)((System.nanoTime() - t0) / 1.0E9);
         if (t > 4.1F) {
            t0 = -1L;
         } else {
            if (layers == null) {
               load();
            }

            renderSideFire(g, t);
            renderRays(g, t);
            float fit = Math.min(g.guiWidth() / 1920.0F, g.guiHeight() / 1080.0F);
            g.pose().pushMatrix();
            g.pose().translate(g.guiWidth() / 2.0F, g.guiHeight() / 2.0F);
            g.pose().scale(fit, fit);
            g.pose().translate(-960.0F, -540.0F);
            float fade = t < 3.3F ? 1.0F : 1.0F - (t - 3.3F) / 0.79999995F;
            float grow;
            if (t < 0.35F) {
               grow = 1.0F;
            } else if (t < 1.25F) {
               grow = 1.0F + 0.06F * easeOut((t - 0.35F) / 0.9F);
            } else {
               grow = 1.06F - 0.07F * smooth((t - 1.25F) / 2.85F);
            }

            float after = t - 0.35F;
            if (after > 0.02F) {
               float k = Mth.clamp((after - 0.02F) / 0.28F, 0.0F, 1.0F);
               float p = easeOut(k);
               float env = smooth((after - 0.35F) / 0.15F) * (1.0F - smooth((t - 2.95F) / 0.3F));
               boolean alive = k >= 1.0F && fade >= 0.999F;

               for (int i = 0; i < EYES.size(); i++) {
                  String name = EYE_NAMES.get(i);
                  TotemTitle.Layer base = EYES.get(i);
                  TotemTitle.Layer pupil = layers.get("pupil_" + name);
                  TotemTitle.Layer lids = layers.get("lids_" + name);
                  float[] range = GAZE.get(name);
                  if (alive && pupil != null && lids != null && range != null) {
                     float[] gz = gaze(t, gazeSeed + i * 7919);
                     float dx = gz[0] * range[0] * env * 0.55F;
                     float dy = gz[1] * range[1] * env * 0.55F;
                     draw(g, base, 960.0F + (base.cx() - 960.0F) * grow, 540.0F + (base.cy() - 540.0F) * grow, grow, 1.0F);
                     draw(g, pupil, 960.0F + (pupil.cx() + dx - 960.0F) * grow, 540.0F + (pupil.cy() + dy - 540.0F) * grow, grow, 1.0F);
                     draw(g, lids, 960.0F + (lids.cx() - 960.0F) * grow, 540.0F + (lids.cy() - 540.0F) * grow, grow, 1.0F);
                  } else {
                     TotemTitle.Layer e = layers.getOrDefault("full_" + name, base);
                     float x = Mth.lerp(p, 960.0F, 960.0F + (e.cx() - 960.0F) * grow);
                     float y = Mth.lerp(p, 540.0F, 540.0F + (e.cy() - 540.0F) * grow);
                     draw(g, e, x, y, Mth.lerp(p, 0.3F, 1.0F) * grow, Math.min(1.0F, k * 1.7F) * fade);
                  }
               }
            }

            TotemTitle.Layer oeye = layers.get("ornament_eye");
            if (oeye != null && after > 0.02F) {
               float k = Mth.clamp((after - 0.02F) / 0.3F, 0.0F, 1.0F);
               draw(g, oeye, 960.0F + (oeye.cx() - 960.0F) * grow, 540.0F + (oeye.cy() - 540.0F) * grow, grow * Mth.lerp(easeOut(k), 0.85F, 1.0F), k * fade);
            }

            if (after > 0.0F) {
               float in = Mth.clamp(after / 0.06F, 0.0F, 1.0F);
               float weak = t < 1.25F ? 1.0F : 1.0F - 0.72F * easeOut((t - 1.25F) / 2.05F);
               float sx = (0.55F + 0.45F * easeOut(after / 0.14F)) * grow * (1.0F + 0.12F * easeOut(Math.min(1.0F, after / 0.9F)));
               sprite(g, "title_flash.png", 2048, 512, 960.0F, 560.0F, 1900.0F * sx, 560.0F * grow, 16777215, in * weak * fade);
               sprite(g, "title_flash.png", 2048, 512, 960.0F, 560.0F, 1500.0F * sx, 420.0F * grow, 16777215, in * weak * fade);
               if (after < 0.4F) {
                  float b = 1.0F - after / 0.4F;
                  sprite(g, "title_flash.png", 2048, 512, 960.0F, 560.0F, 2300.0F * grow, 700.0F * grow, 16777215, b * b * fade);
               }
            }

            TotemTitle.Layer orn = layers.get("ornament");
            if (orn != null && after > 0.02F) {
               float k = Mth.clamp((after - 0.02F) / 0.35F, 0.0F, 1.0F);
               float p = easeOut(k);
               draw(g, orn, 960.0F + (orn.cx() - 960.0F) * grow, 540.0F + (orn.cy() - 540.0F) * grow + 140.0F * (1.0F - p), grow, k * fade);
            }

            for (float[] s : AREA.toArray(new float[0][])) {
               float k = (t - s[2]) / 0.62F;
               if (!(k <= 0.0F) && !(k >= 1.0F)) {
                  float size = s[3] * Mth.sin(k * (float) Math.PI) * grow;
                  sprite(
                     g,
                     "title_sparkle.png",
                     256,
                     256,
                     960.0F + s[0] * grow,
                     540.0F + s[1] * grow,
                     size,
                     size,
                     s[4] > 0.0F ? 0 : 16777215,
                     Math.min(1.0F, Mth.sin(k * (float) Math.PI) * 1.4F) * fade
                  );
               }
            }

            for (float[] sx : SPARKS.toArray(new float[0][])) {
               float k = (t - sx[2]) / 0.66F;
               if (!(k <= 0.0F) && !(k >= 1.0F)) {
                  float size = sx[3] * Mth.sin(k * (float) Math.PI) * grow;
                  sprite(
                     g,
                     "title_sparkle.png",
                     256,
                     256,
                     960.0F + sx[0] * grow,
                     540.0F + sx[1] * grow,
                     size,
                     size,
                     sx[4] > 0.0F ? 0 : 16777215,
                     Math.min(1.0F, Mth.sin(k * (float) Math.PI) * 1.4F) * fade
                  );
               }
            }

            TitleFeathers.render(g, t, fade);
            float ts;
            float ta;
            if (t < 0.35F) {
               float k = t / 0.35F;
               ts = Mth.lerp(k * k, 2.3F, 1.0F);
               ta = Mth.clamp(k * 1.3F, 0.0F, 1.0F);
            } else {
               ts = grow;
               ta = 1.0F;
            }

            TotemTitle.Layer glow = layers.get("title_glow");
            TotemTitle.Layer title = layers.get("title");
            if (glow != null) {
               draw(g, glow, 960.0F + (glow.cx() - 960.0F) * ts, 540.0F + (glow.cy() - 540.0F) * ts, ts, ta * fade);
            }

            if (title != null) {
               draw(g, title, 960.0F + (title.cx() - 960.0F) * ts, 540.0F + (title.cy() - 540.0F) * ts, ts, ta * fade);
            }

            if (title != null && t > 0.35F) {
               sheen(g, title, 960.0F + (title.cx() - 960.0F) * ts, 540.0F + (title.cy() - 540.0F) * ts, ts, t, fade);

               for (float[] q : GLINTS) {
                  float k = (t - q[2]) / q[3];
                  if (!(k <= 0.0F) && !(k >= 1.0F)) {
                     float sz = q[4] * Mth.sin(k * (float) Math.PI) * ts;
                     sprite(
                        g,
                        "title_sparkle.png",
                        256,
                        256,
                        960.0F + (q[0] - 960.0F) * ts,
                        540.0F + (q[1] - 540.0F) * ts,
                        sz,
                        sz,
                        16769240,
                        Math.min(1.0F, Mth.sin(k * (float) Math.PI) * 1.5F) * fade
                     );
                  }
               }
            }

            g.pose().popMatrix();
         }
      }
   }

   private static void renderSideFire(GuiGraphicsExtractor g, float t) {
      float after = t - 0.35F + 0.1F;
      if (!(after <= 0.0F)) {
         float in = easeOut(after / 0.6F);
         float fade = t < 3.3F ? 1.0F : 1.0F - (t - 3.3F) / 0.79999995F;
         float a = in * fade;
         int w = g.guiWidth();
         int h = g.guiHeight();
         float m = Math.min(w, h);
         g.fill(0, 0, w, h, ARGB.color(Mth.clamp((int)(0.16F * a * 255.0F), 0, 255), 40, 0, 6));
         stretch(g, "title_vignette.png", 512, 288, 0.0F, 0.0F, w, h, 16777215, a);
         float ft = t * 16.0F;
         int f0 = Math.floorMod((int)Math.floor(ft), 24);
         int f1 = (f0 + 1) % 24;
         float mix = ft - (float)Math.floor(ft);
         float grow = 0.55F + 0.45F * in;

         for (int side = 0; side < 2; side++) {
            g.pose().pushMatrix();
            if (side == 1) {
               g.pose().translate(w, 0.0F);
               g.pose().scale(-1.0F, 1.0F);
            }

            float tile = h * 0.8F;
            float fw = tile * 0.5F * grow;
            float off = side * tile * 0.43F;

            for (float y = -off; y < h; y += tile) {
               fireFrame(g, "title_fire_side.png", 192, 384, f0, 0.0F, y, fw, tile, a * (1.0F - mix));
               fireFrame(g, "title_fire_side.png", 192, 384, f1, 0.0F, y, fw, tile, a * mix);
            }

            g.pose().popMatrix();
         }

         float tileB = h * 0.95F;
         float fh = tileB * 0.5F * 0.75F * grow;

         for (float x = 0.0F; x < w; x += tileB) {
            fireFrame(g, "title_fire_bottom.png", 384, 192, (f0 + 7) % 24, x, h - fh, tileB, fh, a * (1.0F - mix));
            fireFrame(g, "title_fire_bottom.png", 384, 192, (f1 + 7) % 24, x, h - fh, tileB, fh, a * mix);
         }

         float fhT = fh * 0.8F;
         g.pose().pushMatrix();
         g.pose().translate(0.0F, fhT);
         g.pose().scale(1.0F, -1.0F);

         for (float x = -tileB * 0.37F; x < w; x += tileB) {
            fireFrame(g, "title_fire_bottom.png", 384, 192, (f0 + 15) % 24, x, 0.0F, tileB, fhT, a * 0.9F * (1.0F - mix));
            fireFrame(g, "title_fire_bottom.png", 384, 192, (f1 + 15) % 24, x, 0.0F, tileB, fhT, a * 0.9F * mix);
         }

         g.pose().popMatrix();

         for (float[] q : DOTS) {
            float k = (t - q[2]) / q[3];
            if (!(k <= 0.0F) && !(k >= 1.0F)) {
               float tw = (float)Math.pow(Mth.sin(k * (float) Math.PI), 0.7) * (0.55F + 0.45F * Mth.sin(t * 24.0F + q[0] * 50.0F + q[1] * 31.0F));
               float size = q[4] * m / 540.0F;
               float x = q[0] * w + q[6] * k * q[3] * m;
               float y = q[1] * h + q[7] * k * q[3] * m;
               stretch(g, "title_dot.png", 64, 64, x - size / 2.0F, y - size / 2.0F, size, size, q[5] > 0.5F ? 16756896 : 16726586, tw * a);
               if (size > 2.2F * m / 540.0F) {
                  stretch(g, "title_sparkle.png", 256, 256, x - size * 1.6F, y - size * 1.6F, size * 3.2F, size * 3.2F, 16765128, tw * a * 0.8F);
               }
            }
         }
      }
   }

   private static void renderRays(GuiGraphicsExtractor g, float t) {
      float after = t - 0.35F;
      if (!(after <= 0.0F)) {
         float a = easeOut(after / 0.8F) * (t < 3.3F ? 1.0F : 1.0F - (t - 3.3F) / 0.79999995F);
         int w = g.guiWidth();
         int h = g.guiHeight();

         for (float[] q : RAYS) {
            float breathe = 0.7F + 0.3F * Mth.sin(t * 1.4F + q[4]);
            float ang = q[1] + 0.03F * Mth.sin(t * 0.7F + q[4] * 1.3F);
            float rw = q[2] * w;
            float rh = h * 1.15F;
            g.pose().pushMatrix();
            g.pose().translate(q[0] * w, -0.06F * h);
            g.pose().rotate(ang);
            g.pose().scale(rw / 128.0F, rh / 1024.0F);
            g.blit(
               RenderPipelines.GUI_TEXTURED,
               AnimeCosmetics.id("textures/gui/title/title_ray.png"),
               -64,
               0,
               0.0F,
               0.0F,
               128,
               1024,
               128,
               1024,
               ARGB.color(Mth.clamp((int)(q[3] * breathe * a * 255.0F), 0, 255), 255, 255, 255)
            );
            g.pose().popMatrix();
         }

         float m = Math.min(w, h);

         for (float[] q : DUST) {
            float k = (t - q[2]) / q[3];
            if (!(k <= 0.0F) && !(k >= 1.0F)) {
               float tw = Mth.sin(k * (float) Math.PI) * (0.6F + 0.4F * Mth.sin(t * 9.0F + q[0] * 40.0F));
               float sz = q[4] * m / 540.0F;
               float x = q[0] * w + q[5] * k * q[3] * m;
               float y = q[1] * h + q[6] * k * q[3] * m;
               stretch(g, "title_dot.png", 64, 64, x - sz / 2.0F, y - sz / 2.0F, sz, sz, 16748680, tw * a * 0.85F);
            }
         }
      }
   }

   private static void sheen(GuiGraphicsExtractor g, TotemTitle.Layer l, float x, float y, float s, float t, float fade) {
      float[] starts = new float[]{0.55F, 2.2F};

      for (float st : starts) {
         float p = (t - st) / 0.95F;
         if (!(p <= 0.0F) && !(p >= 1.0F)) {
            float pos = -0.15F + 1.3F * smooth(p);
            int slices = 64;
            int sw = Math.max(1, l.pw() / slices);
            float k = s * l.w() / l.pw();
            g.pose().pushMatrix();
            g.pose().translate(x, y);
            g.pose().scale(k, k);

            for (int i = 0; i * sw < l.pw(); i++) {
               float u = (i + 0.5F) * sw / l.pw();
               float al = (float)Math.exp(-Math.pow((u - pos) / 0.07F, 2.0)) * 0.8F * fade;
               if (!(al < 0.01F)) {
                  int cw = Math.min(sw, l.pw() - i * sw);
                  g.blit(
                     RenderPipelines.GUI_TEXTURED,
                     AnimeCosmetics.id("textures/gui/title/title_sheen.png"),
                     -l.pw() / 2 + i * sw,
                     -l.ph() / 2,
                     i * sw,
                     0.0F,
                     cw,
                     l.ph(),
                     l.pw(),
                     l.ph(),
                     ARGB.color(Mth.clamp((int)(al * 255.0F), 0, 255), 255, 255, 255)
                  );
               }
            }

            g.pose().popMatrix();
         }
      }
   }

   private static void fireFrame(GuiGraphicsExtractor g, String name, int fw, int fh, int frame, float x, float y, float w, float h, float alpha) {
      if (!(alpha <= 0.004F)) {
         int u = frame % 6 * fw;
         int v = frame / 6 * fh;
         int aw = fw * 6;
         int ah = fh * 4;
         g.pose().pushMatrix();
         g.pose().translate(x, y);
         g.pose().scale(w / fw, h / fh);
         g.blit(
            RenderPipelines.GUI_TEXTURED,
            AnimeCosmetics.id("textures/gui/title/" + name),
            0,
            0,
            u + 2,
            v + 2,
            fw,
            fh,
            fw - 4,
            fh - 4,
            aw,
            ah,
            ARGB.color(Mth.clamp((int)(alpha * 255.0F), 0, 255), 255, 255, 255)
         );
         g.pose().popMatrix();
      }
   }

   private static void stretch(GuiGraphicsExtractor g, String name, int pw, int ph, float x, float y, float w, float h, int rgb, float alpha) {
      if (!(alpha <= 0.004F) && !(w <= 0.5F) && !(h <= 0.5F)) {
         g.pose().pushMatrix();
         g.pose().translate(x, y);
         g.pose().scale(w / pw, h / ph);
         g.blit(
            RenderPipelines.GUI_TEXTURED,
            AnimeCosmetics.id("textures/gui/title/" + name),
            0,
            0,
            0.0F,
            0.0F,
            pw,
            ph,
            pw,
            ph,
            ARGB.color(Mth.clamp((int)(alpha * 255.0F), 0, 255), rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF)
         );
         g.pose().popMatrix();
      }
   }

   private static void draw(GuiGraphicsExtractor g, TotemTitle.Layer l, float x, float y, float s, float alpha) {
      if (!(alpha <= 0.004F)) {
         float k = s * l.w() / l.pw();
         g.pose().pushMatrix();
         g.pose().translate(x, y);
         g.pose().scale(k, k);
         g.blit(
            RenderPipelines.GUI_TEXTURED,
            l.tex(),
            -l.pw() / 2,
            -l.ph() / 2,
            0.0F,
            0.0F,
            l.pw(),
            l.ph(),
            l.pw(),
            l.ph(),
            ARGB.color(Mth.clamp((int)(alpha * 255.0F), 0, 255), 255, 255, 255)
         );
         g.pose().popMatrix();
      }
   }

   private static void sprite(GuiGraphicsExtractor g, String name, int pw, int ph, float x, float y, float w, float h, int rgb, float alpha) {
      if (!(alpha <= 0.004F) && !(w <= 0.5F)) {
         g.pose().pushMatrix();
         g.pose().translate(x, y);
         g.pose().scale(w / pw, h / ph);
         g.blit(
            RenderPipelines.GUI_TEXTURED,
            AnimeCosmetics.id("textures/gui/title/" + name),
            -pw / 2,
            -ph / 2,
            0.0F,
            0.0F,
            pw,
            ph,
            pw,
            ph,
            ARGB.color(Mth.clamp((int)(alpha * 255.0F), 0, 255), rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF)
         );
         g.pose().popMatrix();
      }
   }

   public static float[] gaze(float time, int seed) {
      long slot = (long)Math.floor(time / 0.12F);
      long cur = lastJump(slot, seed);
      float[] to = gazePoint(cur, seed);
      float since = time - (float)cur * 0.12F;
      if (since < 0.06F) {
         float[] from = gazePoint(lastJump(cur - 1L, seed), seed);
         float k = smooth(since / 0.06F);
         to = new float[]{Mth.lerp(k, from[0], to[0]), Mth.lerp(k, from[1], to[1])};
      }

      float tx = 0.05F * (float)(Math.sin(time * 23.0 + seed) * 0.6 + Math.sin(time * 37.0 + seed * 1.7) * 0.4);
      float ty = 0.05F * (float)(Math.sin(time * 29.0 + seed * 0.9) * 0.6 + Math.sin(time * 41.0 + seed * 2.3) * 0.4);
      float x = to[0] + tx;
      float y = to[1] + ty;
      float r = (float)Math.sqrt(x * x + y * y);
      return r > 1.0F ? new float[]{x / r, y / r} : new float[]{x, y};
   }

   private static long lastJump(long slot, int seed) {
      int i = 0;

      while (i < 40 && slot > 0L) {
         if (hash01(slot, seed, 1) < 0.3F) {
            return slot;
         }

         i++;
         slot--;
      }

      return Math.max(slot, 0L);
   }

   private static float[] gazePoint(long slot, int seed) {
      if (slot > 0L && !(hash01(slot, seed, 2) < 0.25F)) {
         double a = hash01(slot, seed, 3) * Math.PI * 2.0;
         float r = (float)Math.sqrt(0.3F + 0.7F * hash01(slot, seed, 4));
         return new float[]{(float)Math.cos(a) * r, (float)Math.sin(a) * r};
      } else {
         return new float[]{0.0F, 0.0F};
      }
   }

   private static float hash01(long slot, int seed, int salt) {
      long h = slot * -7046029254386353131L ^ seed * -4417276706812531889L ^ salt * 1609587929392839161L;
      h ^= h >>> 33;
      h *= -49064778989728563L;
      h ^= h >>> 33;
      h *= -4265267296055464877L;
      h ^= h >>> 33;
      return (float)(h >>> 40) / 1.6777216E7F;
   }

   private static float easeOut(float x) {
      x = Mth.clamp(x, 0.0F, 1.0F);
      return 1.0F - (1.0F - x) * (1.0F - x) * (1.0F - x);
   }

   private static float smooth(float x) {
      x = Mth.clamp(x, 0.0F, 1.0F);
      return x * x * (3.0F - 2.0F * x);
   }

   private record Layer(Identifier tex, float x, float y, float w, float h, int pw, int ph) {
      float cx() {
         return this.x + this.w / 2.0F;
      }

      float cy() {
         return this.y + this.h / 2.0F;
      }
   }
}
