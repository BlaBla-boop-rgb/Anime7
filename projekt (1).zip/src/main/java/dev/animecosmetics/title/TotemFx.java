package dev.animecosmetics.title;

import dev.animecosmetics.Toggles;
import net.minecraft.client.Minecraft;

/**
 * When your totem pops: the "Death Can't Die" title (with its own sound) instead of the floating totem
 * and the vanilla totem sound.
 */
public final class TotemFx {
   private static boolean hideVanilla;
   /** True only while the game handles your totem pop, so just the vanilla totem sound is muted. */
   private static boolean mute;

   private TotemFx() {
   }

   public static void register() {
      TotemTitle.register();
   }

   public static void onTotem(Minecraft mc) {
      if (Toggles.get(Toggles.Feature.TOTEM_TITLE)) {
         // the title (and its sound) starts on the next tick, outside the muted moment
         hideVanilla = true;
         mute = true;
      }
   }

   public static boolean muted() {
      return mute;
   }

   public static void endMute() {
      mute = false;
   }

   public static void tick(Minecraft mc) {
      mute = false;
      if (hideVanilla) {
         hideVanilla = false;
         TotemTitle.play();
         if (mc.player != null) {
            // the title takes the centre of the screen, so the floating totem is left out
            mc.player.itemActivation().reset();
         }
      }
   }

   public static void clear() {
      hideVanilla = false;
      mute = false;
      TotemTitle.clear();
   }
}
