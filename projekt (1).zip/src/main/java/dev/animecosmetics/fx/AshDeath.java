package dev.animecosmetics.fx;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.animecosmetics.AnimeCosmetics;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * Kill animation (ported from Ronova's AshDeath): the body darkens, glowing red cracks run over it and it
 * crumbles to ash. Ronova's server keeps dead mobs around for the whole animation; on a normal server the
 * client removes them about one second after death, so here the animation plays {@link #SPEED} times faster.
 */
public final class AshDeath {
   /** Time scale: Ronova's 2.8 s animation fits into the ~1 s a dead mob stays on the client. */
   static final float SPEED = 2.6F;
   private static final int CRACK_FRAMES = 30;
   private static final float GROW_S = 1.3F;
   private static final Identifier CHAR = AnimeCosmetics.id("textures/entity/fx/ash_char.png");
   private static final RenderType[] CRACK_TYPES = new RenderType[30];
   private static RenderType charType;
   private static final Map<Integer, Long> START = new ConcurrentHashMap<>();
   private static final Map<LivingEntityRenderState, Float> STATE = new WeakHashMap<>();
   private static final int SOLID_ALPHA = 26;
   private static final long KEEP_NS = 10000000000L;
   private static final Map<Identifier, AshDeath.Masked> MASKED = new HashMap<>();
   private static final Map<Identifier, NativeImage> SOURCES = new HashMap<>();
   private static int maskSeq;
   public static int layerTint = -1;

   public static void clear() {
      START.clear();
      STATE.clear();
      if (!MASKED.isEmpty() || !SOURCES.isEmpty()) {
         List<Identifier> ids = new ArrayList<>();
         MASKED.values().forEach(m -> ids.addAll(m.ids));
         List<NativeImage> sources = new ArrayList<>(SOURCES.values());
         MASKED.clear();
         SOURCES.clear();
         Minecraft mc = Minecraft.getInstance();
         mc.execute(() -> {
            ids.forEach(mc.getTextureManager()::release);
            sources.forEach(NativeImage::close);
         });
      }
   }

   private AshDeath() {
   }

   public static boolean active(int entityId) {
      return START.containsKey(entityId);
   }

   static void start(int entityId) {
      START.put(entityId, System.nanoTime());
   }

   static void end(int entityId) {
      START.remove(entityId);
   }

   public static float age(int entityId) {
      Long t0 = START.get(entityId);
      return t0 == null ? -1.0F : (float)((System.nanoTime() - t0) / 1.0E9) * SPEED;
   }

   public static double heightScale(double t) {
      double k = Mth.clamp((t - 1.6) / 1.2, 0.0, 1.0);
      return 1.0 - 0.96 * k * k;
   }

   public static void extract(LivingEntity entity, LivingEntityRenderState state) {
      int entityId = entity.getId();
      if (!entity.isDeadOrDying() && age(entityId) > 0.4F * SPEED) {
         end(entityId);
      }

      float t = age(entityId);
      if (t < 0.0F) {
         STATE.remove(state);
      } else {
         STATE.put(state, t);
         state.deathTime = 0.0F;
         state.hasRedOverlay = false;
      }
   }

   public static float of(LivingEntityRenderState state) {
      Float t = STATE.get(state);
      return t == null ? -1.0F : t;
   }

   public static void collapse(LivingEntityRenderState state, PoseStack ps) {
      float t = of(state);
      if (!(t < 0.0F)) {
         float shake = (float)(Mth.clamp(t / 0.2, 0.0, 1.0) * Mth.clamp((1.9 - t) / 0.5, 0.0, 1.0)) * 0.022F;
         if (shake > 0.0F) {
            ps.translate(Math.sin(t * 97.0F) * shake, 0.0, Math.cos(t * 83.0F) * shake);
         }

         float sy = (float)heightScale(t);
         float sxz = 1.0F + 0.18F * (1.0F - sy);
         ps.scale(sxz, sy, sxz);
      }
   }

   public static int tint(LivingEntityRenderState state, int color) {
      float t = of(state);
      if (t < 0.0F) {
         return color;
      } else {
         float k = Mth.clamp(t / 1.0F, 0.0F, 1.0F);
         int dark = ARGB.colorFromFloat(1.0F, Mth.lerp(k, 1.0F, 0.13F), Mth.lerp(k, 1.0F, 0.05F), Mth.lerp(k, 1.0F, 0.06F));
         return ARGB.multiply(color, dark);
      }
   }

   public static int crackColor(LivingEntityRenderState state) {
      float t = of(state);
      if (t < 0.0F) {
         return 0;
      } else {
         float a = Mth.clamp((2.8F - t) / 0.9F, 0.0F, 1.0F);
         a = a * a * (3.0F - 2.0F * a) * (0.9F + 0.1F * Mth.sin(t * 11.0F));
         return ARGB.colorFromFloat(a, 1.0F, 1.0F, 1.0F);
      }
   }

   public static RenderType crackType(LivingEntityRenderState state, Identifier skin) {
      float t = Math.max(0.0F, of(state));
      int f = Mth.clamp((int)(t / 1.3F * 29.0F), 0, 29);
      Identifier tex = AnimeCosmetics.id(String.format("textures/entity/fx/ash_crack_%02d.png", f));
      RenderType m = masked(skin, tex, true);
      if (m != null) {
         return m;
      } else {
         if (CRACK_TYPES[f] == null) {
            CRACK_TYPES[f] = RenderTypes.entityTranslucentEmissive(tex);
         }

         return CRACK_TYPES[f];
      }
   }

   public static int charColor(LivingEntityRenderState state) {
      float t = of(state);
      if (t < 0.0F) {
         return 0;
      } else {
         float a = Mth.clamp((t - 0.1F) / 0.9F, 0.0F, 1.0F);
         return ARGB.colorFromFloat(a * 0.9F, 1.0F, 1.0F, 1.0F);
      }
   }

   public static RenderType charType(Identifier skin) {
      RenderType m = masked(skin, CHAR, false);
      if (m != null) {
         return m;
      } else {
         if (charType == null) {
            charType = RenderTypes.entityTranslucent(CHAR);
         }

         return charType;
      }
   }

   private static RenderType masked(Identifier skin, Identifier tex, boolean emissive) {
      long now = System.nanoTime();
      AshDeath.Masked m = MASKED.get(skin);
      if (m == null) {
         evict(now);
         m = new AshDeath.Masked();

         try {
            readMask(skin, m);
         } catch (Exception var16) {
            AnimeCosmetics.LOGGER.warn("ash mask {}: {}", skin, var16.toString());
         }

         MASKED.put(skin, m);
      }

      m.used = now;
      if (m.solid == null) {
         return null;
      } else if (m.types.containsKey(tex)) {
         return m.types.get(tex);
      } else {
         RenderType type = null;

         try {
            NativeImage src = SOURCES.get(tex);
            if (src == null) {
               try (InputStream in = Minecraft.getInstance().getResourceManager().open(tex)) {
                  src = NativeImage.read(in);
               }

               SOURCES.put(tex, src);
            }

            int w = Math.max(src.getWidth(), m.w);
            int h = Math.max(src.getHeight(), m.h);
            NativeImage out = new NativeImage(w, h, true);

            for (int y = 0; y < h; y++) {
               int my = y * m.h / h;
               int sy = y * src.getHeight() / h;

               for (int x = 0; x < w; x++) {
                  if (m.solid[x * m.w / w + my * m.w]) {
                     out.setPixel(x, y, src.getPixel(x * src.getWidth() / w, sy));
                  }
               }
            }

            Identifier id = AnimeCosmetics.id("ash_mask/" + maskSeq++);
            Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(id::toString, out));
            m.ids.add(id);
            type = emissive ? RenderTypes.entityTranslucentEmissive(id) : RenderTypes.entityTranslucent(id);
         } catch (Exception var18) {
            AnimeCosmetics.LOGGER.warn("ash mask {} for {}: {}", new Object[]{tex, skin, var18.toString()});
         }

         m.types.put(tex, type);
         return type;
      }
   }

   private static void evict(long now) {
      TextureManager tm = Minecraft.getInstance().getTextureManager();
      MASKED.values().removeIf(m -> {
         if (now - m.used < 10000000000L) {
            return false;
         } else {
            m.ids.forEach(tm::release);
            return true;
         }
      });
      if (MASKED.isEmpty()) {
         SOURCES.values().forEach(NativeImage::close);
         SOURCES.clear();
      }
   }

   private static void readMask(Identifier skin, AshDeath.Masked m) throws IOException {
      Minecraft mc = Minecraft.getInstance();
      boolean own = false;
      NativeImage img;
      if (mc.getTextureManager().getTexture(skin) instanceof DynamicTexture d && d.getPixels() != null) {
         img = d.getPixels();
      } else {
         Optional<Resource> res = mc.getResourceManager().getResource(skin);
         if (res.isEmpty()) {
            return;
         }

         try (InputStream in = res.get().open()) {
            img = NativeImage.read(in);
         }

         own = true;
      }

      try {
         int w = img.getWidth();
         int h = img.getHeight();
         boolean[] solid = new boolean[w * h];
         boolean holes = false;

         for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
               solid[x + y * w] = ARGB.alpha(img.getPixel(x, y)) >= 26;
               holes |= !solid[x + y * w];
            }
         }

         if (holes) {
            m.w = w;
            m.h = h;
            m.solid = solid;
         }
      } finally {
         if (own) {
            img.close();
         }
      }
   }

   private static final class Masked {
      int w;
      int h;
      boolean[] solid;
      final Map<Identifier, RenderType> types = new HashMap<>();
      final List<Identifier> ids = new ArrayList<>();
      long used;
   }
}
