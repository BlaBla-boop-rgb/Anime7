package dev.animecosmetics.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import dev.animecosmetics.AnimeCosmetics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Own particles for the kill animation: glowing sparks/embers (additive) and dark ash flakes.
 * They are drawn by the mod itself, so no particle types have to be registered (works on any server).
 */
final class KillParticles {
   private static final Identifier SPARK_TEX = AnimeCosmetics.id("textures/entity/fx/kill_spark.png");
   private static final Identifier FLAKE_TEX = AnimeCosmetics.id("textures/entity/fx/kill_flake.png");
   private static final int MAX = 1500;
   private static final List<KillParticles.P> SPARKS = new ArrayList<>();
   private static final List<KillParticles.P> FLAKES = new ArrayList<>();
   private static final Random RND = new Random();
   private static long lastNs = -1L;

   private KillParticles() {
   }

   static void register() {
      LevelRenderHooks.onCollectSubmits(KillParticles::render);
   }

   static void clear() {
      SPARKS.clear();
      FLAKES.clear();
      lastNs = -1L;
   }

   /** Glowing spark. rgb e.g. 0xFF5030; size in blocks; life in seconds; lift = upward pull (negative gravity). */
   static void spark(Vec3 p, Vec3 v, int rgb, float size, float life, float lift) {
      if (SPARKS.size() < MAX) {
         SPARKS.add(new KillParticles.P(p, v, rgb, size, life, lift, 0.9F, RND.nextFloat() * 6.28F));
      }
   }

   /** Dark ash flake that drifts and slowly sinks. */
   static void flake(Vec3 p, Vec3 v, int rgb, float size, float life) {
      if (FLAKES.size() < MAX) {
         FLAKES.add(new KillParticles.P(p, v, rgb, size, life, -0.6F, 0.8F, RND.nextFloat() * 6.28F));
      }
   }

   private static void step(List<KillParticles.P> list, float dt) {
      list.removeIf(p -> {
         p.age += dt;
         if (p.age >= p.life) {
            return true;
         } else {
            float drag = (float)Math.pow(p.drag, dt * 20.0F);
            p.vx *= drag;
            p.vy = p.vy * drag + p.lift * dt;
            p.vz *= drag;
            // a little swirl, like hot air
            p.vx += Math.sin(p.age * 5.0F + p.spin) * 0.06F * dt;
            p.vz += Math.cos(p.age * 4.3F + p.spin) * 0.06F * dt;
            p.x += p.vx * dt * 20.0F;
            p.y += p.vy * dt * 20.0F;
            p.z += p.vz * dt * 20.0F;
            return false;
         }
      });
   }

   private static void render(LevelRenderHooks.Context ctx) {
      long now = System.nanoTime();
      float dt = lastNs < 0L ? 0.0F : Math.min(0.1F, (float)(now - lastNs) / 1.0E9F);
      lastNs = now;
      if (SPARKS.isEmpty() && FLAKES.isEmpty()) {
         return;
      }

      step(SPARKS, dt);
      step(FLAKES, dt);
      Vec3 cam = ctx.levelState().cameraRenderState.pos;
      Quaternionf rot = ctx.levelState().cameraRenderState.orientation;
      Vector3f right = rot.transform(new Vector3f(1.0F, 0.0F, 0.0F));
      Vector3f up = rot.transform(new Vector3f(0.0F, 1.0F, 0.0F));
      if (!FLAKES.isEmpty()) {
         List<KillParticles.P> flakes = new ArrayList<>(FLAKES);
         ctx.submitNodeCollector().submitCustomGeometry(new PoseStack(), RiftTypes.soft(FLAKE_TEX), (pose, buf) -> {
            for (KillParticles.P p : flakes) {
               float k = p.age / p.life;
               float a = Math.min(1.0F, k / 0.08F) * (1.0F - k * k) * 0.9F;
               quad(pose, buf, p, cam, right, up, p.size * (0.8F + 0.4F * k), a);
            }
         });
      }

      if (!SPARKS.isEmpty()) {
         List<KillParticles.P> sparks = new ArrayList<>(SPARKS);
         ctx.submitNodeCollector().order(2).submitCustomGeometry(new PoseStack(), FxTypes.glowAdd(SPARK_TEX), (pose, buf) -> {
            for (KillParticles.P p : sparks) {
               float k = p.age / p.life;
               float flicker = 0.75F + 0.25F * (float)Math.sin(p.age * 31.0F + p.spin * 7.0F);
               float a = Math.min(1.0F, k / 0.05F) * (1.0F - k) * flicker;
               quad(pose, buf, p, cam, right, up, p.size * (1.0F - 0.5F * k), a);
            }
         });
      }
   }

   private static void quad(Pose pose, VertexConsumer buf, KillParticles.P p, Vec3 cam, Vector3f right, Vector3f up, float size, float a) {
      if (!(a <= 0.003F)) {
         float h = size / 2.0F;
         float c = (float)Math.cos(p.spin + p.age * 2.0F);
         float s = (float)Math.sin(p.spin + p.age * 2.0F);
         // rotated billboard
         float rx = (right.x * c + up.x * s) * h;
         float ry = (right.y * c + up.y * s) * h;
         float rz = (right.z * c + up.z * s) * h;
         float ux = (up.x * c - right.x * s) * h;
         float uy = (up.y * c - right.y * s) * h;
         float uz = (up.z * c - right.z * s) * h;
         float x = (float)(p.x - cam.x);
         float y = (float)(p.y - cam.y);
         float z = (float)(p.z - cam.z);
         float r = (p.rgb >> 16 & 0xFF) / 255.0F;
         float g = (p.rgb >> 8 & 0xFF) / 255.0F;
         float b = (p.rgb & 0xFF) / 255.0F;
         vtx(pose, buf, x - rx - ux, y - ry - uy, z - rz - uz, 0.0F, 1.0F, r, g, b, a);
         vtx(pose, buf, x + rx - ux, y + ry - uy, z + rz - uz, 1.0F, 1.0F, r, g, b, a);
         vtx(pose, buf, x + rx + ux, y + ry + uy, z + rz + uz, 1.0F, 0.0F, r, g, b, a);
         vtx(pose, buf, x - rx + ux, y - ry + uy, z - rz + uz, 0.0F, 0.0F, r, g, b, a);
      }
   }

   private static void vtx(Pose pose, VertexConsumer buf, float x, float y, float z, float u, float v, float r, float g, float b, float a) {
      buf.addVertex(pose, x, y, z)
         .setColor(r, g, b, a)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
   }

   private static final class P {
      double x;
      double y;
      double z;
      float vx;
      float vy;
      float vz;
      final int rgb;
      final float size;
      final float life;
      final float lift;
      final float drag;
      final float spin;
      float age;

      P(Vec3 p, Vec3 v, int rgb, float size, float life, float lift, float drag, float spin) {
         this.x = p.x;
         this.y = p.y;
         this.z = p.z;
         this.vx = (float)v.x;
         this.vy = (float)v.y;
         this.vz = (float)v.z;
         this.rgb = rgb;
         this.size = size;
         this.life = life;
         this.lift = lift * 0.1F;
         this.drag = drag;
         this.spin = spin;
      }
   }
}
