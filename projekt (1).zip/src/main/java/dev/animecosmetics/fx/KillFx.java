package dev.animecosmetics.fx;

import dev.animecosmetics.AnimeCosmetics;
import dev.animecosmetics.Toggles;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * "Kill-Animation": what you kill crumbles to ash (Ronova's AshDeath).
 *
 * The client does not know who killed a mob, so this remembers what you hit yourself: if it dies within
 * a few seconds of your last hit, it turns to ash. Sounds: Ronova's "death_doom" on the kill and "ash" when the
 * body breaks apart. Particles: the mod's own glowing sparks and ash flakes (see {@link KillParticles}).
 */
public final class KillFx {
   /** Seconds after your last hit in which a death still counts as your kill. */
   private static final float HIT_WINDOW = 4.0F;
   private static final SoundEvent SOUND_ASH = SoundEvent.createFixedRangeEvent(AnimeCosmetics.id("ash"), 24.0F);
   private static final SoundEvent SOUND_DOOM = SoundEvent.createFixedRangeEvent(AnimeCosmetics.id("death_doom"), 32.0F);
   private static final RandomSource SOUND_RND = RandomSource.create();
   private static final Random RND = new Random();
   /** Entity id -> time of your last hit. */
   private static final Map<Integer, Long> HITS = new HashMap<>();
   /** Entity id -> last known body (centre, width, height) of a mob that is turning to ash. */
   private static final Map<Integer, double[]> BURNING = new HashMap<>();

   private KillFx() {
   }

   public static void register() {
      KillParticles.register();
      AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level.isClientSide() && player == mc.player && entity instanceof LivingEntity) {
            HITS.put(entity.getId(), System.nanoTime());
         }

         return InteractionResult.PASS;
      });
   }

   public static void clear() {
      HITS.clear();
      BURNING.clear();
      AshDeath.clear();
      KillParticles.clear();
   }

   public static void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null) {
         return;
      }

      long now = System.nanoTime();
      boolean on = Toggles.get(Toggles.Feature.KILL_FX);
      Iterator<Map.Entry<Integer, Long>> it = HITS.entrySet().iterator();

      while (it.hasNext()) {
         Map.Entry<Integer, Long> e = it.next();
         Entity entity = mc.level.getEntity(e.getKey());
         if ((float)(now - e.getValue()) / 1.0E9F > HIT_WINDOW || entity == null) {
            it.remove();
         } else if (entity instanceof LivingEntity le && le.isDeadOrDying()) {
            it.remove();
            if (on && entity != mc.player) {
               AshDeath.start(entity.getId());
               double[] b = body(entity);
               BURNING.put(entity.getId(), b);
               sound(mc, SOUND_DOOM, b, 0.8F, 0.9F + SOUND_RND.nextFloat() * 0.15F);
               killBurst(b);
            }
         }
      }

      Iterator<Map.Entry<Integer, double[]>> bt = BURNING.entrySet().iterator();

      while (bt.hasNext()) {
         Map.Entry<Integer, double[]> e = bt.next();
         Entity entity = mc.level.getEntity(e.getKey());
         if (entity != null && !entity.isRemoved()) {
            double[] b = body(entity);
            e.setValue(b);
            // embers rising from the cracks while it burns
            for (int i = 0; i < 6; i++) {
               KillParticles.spark(inBody(b), new Vec3(0.0, 0.02 + RND.nextDouble() * 0.04, 0.0), ember(), 0.08F + RND.nextFloat() * 0.08F, 0.8F + RND.nextFloat() * 0.8F, 1.0F);
            }
         } else {
            // the body is gone: it breaks into ash
            double[] b = e.getValue();
            sound(mc, SOUND_ASH, b, 0.7F, 0.95F + SOUND_RND.nextFloat() * 0.1F);
            ashBurst(mc, b);
            AshDeath.end(e.getKey());
            bt.remove();
         }
      }
   }

   private static void sound(Minecraft mc, SoundEvent e, double[] b, float volume, float pitch) {
      mc.getSoundManager().play(new SimpleSoundInstance(e, SoundSource.PLAYERS, volume, pitch, SOUND_RND, b[0], b[1] + b[4] / 2.0, b[2]));
   }

   private static int ember() {
      int[] c = {0xFF3A1E, 0xFF5A2A, 0xFF8A3C, 0xE0201A};
      return c[RND.nextInt(c.length)];
   }

   private static Vec3 inBody(double[] b) {
      return new Vec3(b[0] + (RND.nextDouble() - 0.5) * b[3], b[1] + RND.nextDouble() * b[4], b[2] + (RND.nextDouble() - 0.5) * b[3]);
   }

   private static Vec3 outward(double[] b, Vec3 p, double speed, double up) {
      Vec3 d = new Vec3(p.x - b[0], 0.0, p.z - b[2]);
      d = d.lengthSqr() < 1.0E-4 ? new Vec3(RND.nextDouble() - 0.5, 0.0, RND.nextDouble() - 0.5) : d;
      return d.normalize().scale(speed).add(0.0, up, 0.0);
   }

   /** The moment of the kill: a flash of red sparks bursting out of the body. */
   private static void killBurst(double[] b) {
      int n = (int)Math.min(90.0, 35.0 + b[3] * b[4] * 25.0);

      for (int i = 0; i < n; i++) {
         Vec3 p = inBody(b);
         KillParticles.spark(p, outward(b, p, 0.08 + RND.nextDouble() * 0.18, 0.04 + RND.nextDouble() * 0.12), ember(), 0.1F + RND.nextFloat() * 0.14F, 0.5F + RND.nextFloat() * 0.6F, 0.6F);
      }

      // a ring of sparks along the ground
      for (int i = 0; i < 28; i++) {
         double a = i / 28.0 * Math.PI * 2.0;
         Vec3 p = new Vec3(b[0] + Math.cos(a) * 0.2, b[1] + 0.05, b[2] + Math.sin(a) * 0.2);
         KillParticles.spark(p, new Vec3(Math.cos(a) * 0.22, 0.01, Math.sin(a) * 0.22), 0xFF2A18, 0.16F, 0.6F, 0.0F);
      }
   }

   /** The body breaks apart: ash flakes, glowing cinders rising and a little smoke. */
   private static void ashBurst(Minecraft mc, double[] b) {
      int n = (int)Math.min(140.0, 40.0 + b[3] * b[4] * 45.0);

      for (int i = 0; i < n; i++) {
         Vec3 p = inBody(b);
         int grey = 0x1E1A19 + RND.nextInt(3) * 0x0A0909;
         KillParticles.flake(p, outward(b, p, 0.03 + RND.nextDouble() * 0.08, 0.02 + RND.nextDouble() * 0.08), grey, 0.12F + RND.nextFloat() * 0.16F, 1.6F + RND.nextFloat() * 1.6F);
      }

      for (int i = 0; i < n / 2; i++) {
         Vec3 p = inBody(b);
         KillParticles.spark(p, outward(b, p, 0.02 + RND.nextDouble() * 0.05, 0.03 + RND.nextDouble() * 0.06), ember(), 0.06F + RND.nextFloat() * 0.1F, 1.2F + RND.nextFloat() * 1.4F, 1.5F);
      }

      for (int i = 0; i < n / 6; i++) {
         Vec3 p = inBody(b);
         mc.level.addParticle(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 0.0, 0.02 + RND.nextDouble() * 0.03, 0.0);
      }
   }

   private static double[] body(Entity e) {
      return new double[]{e.getX(), e.getY(), e.getZ(), e.getBbWidth(), e.getBbHeight()};
   }

}
